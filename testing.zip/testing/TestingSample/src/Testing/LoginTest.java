package Testing;

import static org.junit.Assert.*;

import org.junit.Test;

public class LoginTest {

	@Test
	public void test() {
		
		Login l=new Login();
		
			assertEquals("Invalid username or password",true,l.login("john", "123"));
		
		
	}

}
