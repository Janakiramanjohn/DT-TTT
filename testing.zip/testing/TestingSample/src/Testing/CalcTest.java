package Testing;

import static org.junit.Assert.*;

import org.junit.Test;

public class CalcTest {

	@Test
	public void test() {
		 Sample s=new Sample();
		 assertEquals(30,s.add(12,18));
	}
	
	@Test
	public void subT()
	{
		Sample s=new Sample();
		assertEquals(10,s.sub(40, 20));
	}

}
