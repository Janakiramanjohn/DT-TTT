package Testing;

public class Login {

	
	
	public boolean login(String username,String password)
	{
		if(username.equals("john"))
		{
			if(password.equals("123"))
			{
				return true;	
			}
			else
			{
				return false;
			}
		}
		else
		{
			return false;
		}
			 
	}
	
	
	
}
