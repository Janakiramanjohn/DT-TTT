package com.niit.UnitTesting;

public class TestingClass {
	
	
	public int add(int a,int b)
	{
		
		return a+b;
	}
	
	public int Sub(int a,int b)
	{
		
		return a-b;
	}

}
