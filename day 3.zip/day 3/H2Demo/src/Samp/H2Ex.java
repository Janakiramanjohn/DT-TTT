package Samp;
 import java.sql.Connection;
import java.util.*;
import java.sql.*;
public class H2Ex {

	public static void main(String[] args) {
		try{  
		Class.forName("org.h2.Driver");
		Connection con=DriverManager.getConnection(  
				"jdbc:h2:tcp://localhost/~/TTTDay3","sa","");  
				  
				Statement stmt=con.createStatement();  
				ResultSet rs=stmt.executeQuery("select * from Stud");  
				while(rs.next())  
				System.out.println(rs.getInt(1)+"  "+rs.getString(2)+"  "+rs.getString(3));  
				con.close();  
				}catch(Exception e){ System.out.println(e);}  
				
	}

}
