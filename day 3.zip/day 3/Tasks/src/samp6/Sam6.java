package samp6;

import java.util.Scanner;

public class Sam6 {

	static void palindrome()
	{String rev="";
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a String ");
		String str=sc.nextLine();
		int l=str.length();
		for(int i=l-1;i>=0;i--)
			rev+=str.charAt(i);
		if(rev.equals(str))
			System.out.println("Palindrome ");
		else
			System.out.println("Not a Palindrome");
		
	}
	
//	public static void main(String[] args) {
//	 
//		palindrome();
//		
//	}

}
