package samp5;

public class Sam5 {

	static void fibbo()
	{
		
		System.out.println("Fibbonacci Series");
		 int n1=0,n2=1;  
		 System.out.print(n1+" "+n2);
		  
		 while(true){ 
		  n2=n1+n2;  
		if(n2<200){
		  System.out.print(" "+n2);  
		  n1=n2-n1;  
		 }
		else
		{
			break;
		}
		 }  

		
	}
	
//	
//	public static void main(String[] args) {
//	
//		fibbo();
//		
//		
//
//	}

}
