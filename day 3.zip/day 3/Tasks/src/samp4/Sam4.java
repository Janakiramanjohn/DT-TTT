package samp4;

import java.util.Scanner;

public class Sam4 {
	static void prime(){
		
		Scanner sc=new Scanner(System.in);
		System.out.println("�nter a number");
		int n=sc.nextInt();
		for(int i=2;i<n/2;i++)
		{
			if(n%i==0)
			{
				System.out.println(n+" is Not a Prime Number");
				break;
			}
			else if(i==((n/2)-1))
			{
				System.out.println(n+" is  a Prime Number");
			}
			
		}
		
	}
	
//	public static void main(String []p)
//	{
//		prime();
//	}

}
