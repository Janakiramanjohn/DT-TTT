package samp1;

import java.util.Scanner;

public class Home {

	void Star(int n) {

		for (int row = n; row >= 1; --row) {
			for (int col = 1; col <= row; ++col) {
				System.out.print(col);
			}

			System.out.println();
		}

	}

//	public static void main(String[] aa) {
//
//		Home h = new Home();
//		Scanner sc = new Scanner(System.in);
//		int n = sc.nextInt();
//		h.Star(n);
//	}

}
