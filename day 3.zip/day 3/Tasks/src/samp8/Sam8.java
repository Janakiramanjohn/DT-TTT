package samp8;

import java.util.Scanner;

public class Sam8 {
static void fact()
{
Scanner sc=new Scanner(System.in);
System.out.println("Enter a Number");
int f=1,n=sc.nextInt();

for(int i=1;i<=n;i++)
{

	f*=i;
	
}
System.out.println(f);
}
	
	public static void main(String[] args) {
	 
	fact();	
	}

}
