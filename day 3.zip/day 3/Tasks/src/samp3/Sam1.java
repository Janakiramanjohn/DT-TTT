package samp3;


import java.util.Scanner;

public class Sam1 {

	static void diamon()
	{
		
		 Scanner sc=new Scanner(System.in);
			int number, i, k, count = 1;
	        System.out.println("Enter number of rows\n");
	        number = sc.nextInt();
	        count = number - 1;
	        for (k = 1; k <= number; k++)
	        {
	            for (i = 1; i <= count; i++)
	               System.out.print(" ");
	            count--;
	            for (i = 1; i <= 2 * k - 1; i++)
	            	System.out.print("*");
	            System.out.println();
	        }
	        count = 1;
	        for (k = 1; k <= number - 1; k++)
	        {
	            for (i = 1; i <= count; i++)
	            	System.out.print(" ");
	            count++;
	            for (i = 1; i <= 2 * (number - k) - 1; i++)
	            	System.out.print("*");
	            System.out.println();
	        }
	 	
	}
	
//	public static void main(String[] args) {
//		diamon();
//
//	}

}
