package samp7;

import java.util.Scanner;

public class Sam7 {

	static void Armstrong ()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a Number");
		int n=sc.nextInt();
		int a=0,t=n;
		while(n>0)
		{
			int rem=n%10;
			a+=Math.pow(rem, 3);
			n/=10;
			
		}
		if(a==t)
			System.out.println("Armstrong Number");
		else
			System.out.println("Not a Armstrong Number");
		
	}
//	
//	public static void main(String[] args) {
//		Armstrong();
//		
//		
//	}

}
